---
name: openverse-media
description: Openverse 免费素材搜索（菲菲版）：用免 Key 的 Openverse API 搜 CC 授权的音频（音效/环境音/音乐）与图片，带 license 过滤、商用过滤与署名文本，curl 即可。用于给视频/空间/小游戏找真素材；代码合成音效查 cuelume、合成配乐查 Tone.js。源 WordPress/openverse（MIT 代码，素材各自 CC 授权），2026-11-27 curl 实测通过。
---

# Openverse 免费素材（菲菲适配，2026-11-27 装+实测）

来源：主人点选帖 @3three_AI 2125791906022175110（20 仓库清单第 17 件）。
上游：github.com/WordPress/openverse，MIT（指其代码），824 星。**注意分工：仓库本体是个 1.6 GB 的 monorepo（GitHub API 实读 size=1,622,288 KB），不是技能包、不要克隆**；菲菲用的只是它对外运营的公共 API：`https://api.openverse.org/v1/`。本机只存实测样本 JSON 在 ~/workspace/openverse-lab/（test-rain-audio.json / test-commercial.json / test-rain-images.json），没有 repo 克隆，这是刻意决定、不是漏装。

## 它是什么
WordPress 旗下的开放授权素材搜索引擎，聚合 Freesound、Flickr、Wikimedia 等来源的 CC 素材。匿名免 Key 可搜可下（有速率上限，见规矩），返回结构化字段：标题、作者、license 与版本、license 链接、直链 url、来源 provider、以及**现成的 attribution 署名文本**。

## API 用法（curl，全部实测过）

### 搜音频（音效/环境音/音乐）
```sh
curl -s "https://api.openverse.org/v1/audio/?q=rain%20sound&page_size=5"
# 只看字段精简版：
curl -s "https://api.openverse.org/v1/audio/?q=rain%20sound&page_size=3" | python3 -c "import sys,json; d=json.load(sys.stdin); [print(r['title'],'|',r['creator'],'|',r['license'],r['license_version'],'|',r['url']) for r in d['results']]"
```
常用参数：
- `q` 关键词（英文命中率明显更高，先用英文搜）
- `license=cc0,by,by-sa` 只留指定授权（逗号分隔）
- `license_type=commercial` 只留可商用（自动排除 NC）；`license_type=modification` 只留可改作
- `category=music` 只要音乐类（音频类别还有 sound_effect 等，以返回字段为准）
- `page_size`（默认 20，最大 500）/ `page` 翻页
- 单条详情：`https://api.openverse.org/v1/audio/<id>/`；图片同理换 `images`

### 搜图片
```sh
curl -s "https://api.openverse.org/v1/images/?q=rain&license=cc0&page_size=5"
```

### 返回关键字段
`title / creator / creator_url / license / license_version / license_url / url（文件直链）/ foreign_landing_url（来源页）/ provider / attribution（官方拼好的署名句）/ filesize / filetype / duration（音频，毫秒）`

## 授权纪律（硬规矩，出片/上架前必过）
| license | 能不能用 | 署名 |
|---|---|---|
| cc0 / pdm | 随便用（含商用、可改） | 法律上不需，但菲菲默认仍在片尾/说明里记一笔来源 |
| by | 可用（含商用、可改） | **必须署名**：用返回的 `attribution` 原句 |
| by-sa | 可用，改作须同授权释出 | 必须署名 + 同授权 |
| by-nc / by-nc-sa / by-nc-nd | **非商用才行**；nd 连改作都不行 | 必须署名；主人的变现内容（X 收益/小游戏/售卖站配图配乐）**一律不用 NC/ND** |
口径：给主人任何带变现目的的产物找素材，默认加 `license_type=commercial` 过滤；最终用哪条，把 title/creator/license 记进产物目录的来源清单，不许用完就忘出处。

## 实测（2026-11-27，curl 直连，HTTP 200）
- 音频 `q=rain sound`：result_count=240，前 3 条全是 Freesound 的 CC0 1.0：
  1. “Rain Sound and Rainforest.mp3” — INNORECORDS — CC0 1.0（240 秒，mp3 直链 cdn.freesound.org）
  2. “Birds in Rain Sounds (Scotland).wav” — BurghRecords — CC0 1.0
  3. “Rain sound, Water drops” — Danut05 — CC0 1.0
- 音频商用过滤 `q=rain&license_type=commercial`：HTTP 200，前 2 条 “Rain, Moderate, C.wav” / “Rain, Moderate, A.wav” — InspectorJ — CC BY 4.0（过滤生效，NC 类被排除）。
- 音频音乐类 `q=jazz&category=music`：返回 “Jingle Jazz”（by-sa）、“Jazz Momentum”（by-nc-nd）等——再次证明不加过滤会混进 NC/ND，变现产物必须过滤。
- 图片 `q=rain&license=cc0`：返回 CC0 条目如 “Rain - Jupiter Agreements - IMG_0151-002” — iezalel7williams — cc0（Flickr 来源）。
- 注：result_count 多次显示 240，是该接口当前返回口径（分页上限相关），按实读记录，不外推总量。

## 分工
| 需求 | 查谁 |
|---|---|
| 真录音素材：环境音、音效、现成音乐、CC 图片 | **本技能（Openverse）** |
| 网页 UI 交互音效（点击/成功/报错，代码实时合成、无音频文件） | `cuelume` |
| 代码合成的旋律/节拍/BGM 原型（Tone.Offline 离线渲染） | Tone.js（~/workspace/tonejs-lab） |
| 正式成片配乐 | 仍走现役配乐路线；Openverse 只做素材来源，选中后照授权纪律登记 |

互补关系一句话：cuelume/Tone 是「自己合成」，Openverse 是「找现成的真录音」——要雨声、鸟鸣、真实环境底噪这类合成不像的东西，直接来这里搜。

## 使用规矩
- 匿名 API 有速率上限：批量搜要串行、带间隔，别并发猛刷；被 429 就停手等恢复，不换路绕。
- 下载只下最终选定的少数文件，别整页批量搬运。
- 不注册、不申请 API Key（匿名够用；要提额须主人点头再走 OAuth 注册流程）。
- 素材直链是第三方 CDN（freesound/flickr 等），交付前实测能打开再用。
