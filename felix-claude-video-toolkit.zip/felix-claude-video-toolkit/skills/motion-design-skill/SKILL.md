---
name: motion-design-skill
description: LottieFiles motion-design 的菲菲版：动效的「导演层」原则库——三支柱（情感意图/视觉叙事/动效工艺）、四种 Motion Personality、迪士尼 12 原则的 UI 适配、情绪→动效映射、1/3 法则与编排、材质缓动。用于给视频/动画/交互先定情感、性格与叙事再落数值；具体时长/缩放/弹簧定版查 better-motion，技法查 emil-design-eng，表面抛光查 better-ui。源 LottieFiles/motion-design-skill（MIT），菲菲手工重写，未复制原文文件。
---

# Motion Design（导演/原则层 · 菲菲适配，2026-11-27 装+核对）

来源：主人点选帖 @3three_AI 2125791906022175110（20 仓库清单第 1 件）。
上游：github.com/LottieFiles/motion-design-skill，MIT，3,760 星 / 284 fork（2026-11-27 GitHub API 实读），默认分支 main，2026-11-23 仍在更新。
原仓：~/workspace/motion-design-lab/repo（tarball 落地，104 KB，21 个文件，全是 Markdown，零代码）。

## 审计结论（2026-11-27）
- 全仓只有 .md + LICENSE + README，没有脚本、二进制、依赖清单，无从谈 eval / 子进程 / 外发代码。
- 唯一的对外指向是商业引流：README 与 `reference/export-and-render.md` 建议连接 LottieFiles 的 **Creator MCP**（远程 MCP，`creator.mcp.lottiefiles.com`）来导出 MP4/GIF/Lottie 文件。**菲菲版剥掉这一条**：不装、不推荐连这个 MCP；要导出成片走现役 Remotion / HyperFrames / ffmpeg 管线。技能本体（原则部分）与该 MCP 无关，离线可用。

## 它是什么（与现有技能的根本区别）
这是一套**决策顺序**，不是数值表也不是技法集：先定「观众应该有什么感觉、这段动效讲什么微故事、用什么性格」，再谈时长和曲线。适合用在做片/做动画/做交互动效的**最前面定调**，尤其是视频类（Remotion / claude-animation-skills / HyperFrames 出片前）和品牌向页面。

## 分工（先看这张表，别拿错技能）
| 问题 | 查谁 |
|---|---|
| 这段动效该有什么情感、性格、叙事？多元素怎么编排不乱？ | **本技能** |
| 时长多少 ms、按压缩放多少、弹簧怎么写、stagger 多少？ | `better-motion`（菲菲定版：按压 0.96/150ms、弹簧 bounce 恒 0，以那边为准） |
| clip-path、blur 交叉淡化、手势阻尼、tooltip 免延迟等具体技法与动效审查 | `emil-design-eng` |
| 圆角、阴影、图标线宽、hover 门控等表面数值抛光 | `better-ui` |
| 做片的整体导演层（观众变化/贯穿线/声画排程） | `chaojifeng-video-design`（管全片，本技能只管「动」这一层） |

重叠说明：本技能的时长/缓动表与 better-motion 约有三成重叠且个别值不同（例如它主张入场比出场长 30–50%，better-motion 主张出场更短，方向一致但数值口径不同）。**冲突时一律以 better-motion 的菲菲定版为准**，本技能只取它独有的四块：三支柱、四性格、情绪映射、1/3 编排法则。

## 核心内容（菲菲提炼版）

### 动工前 8 问（按序答，答不出就别动手）
1. 情感目标是什么？（joy / calm / urgency / elegance…）
2. Motion Personality 选哪一型？（全项目只选一型，见下）
3. 主属性是什么？（position / scale / rotation / opacity 只选一个主的）
4. 时长？（落 better-motion 定版表）
5. 缓动族？（入场减速、出场加速、屏内移动双端平滑）
6. 谁是 Hero 元素？（staging：主角先行或最醒目）
7. 次级层与环境层各是什么？（见三层）
8. 过 1/3 法则了吗？（见编排）

### 三支柱 + 三层
- 三支柱：**情感意图**（观众该有什么感觉，驱动缓动/时长/幅度）、**视觉叙事**（微故事：Setup → Action → Resolution）、**动效工艺**（物理可信：次级运动、路径、重量感）。
- 三层缺一显廉价：**Primary** 主动作、**Secondary** 附带丰富度（阴影、图标位移）、**Ambient** 背景生命（渐变、微脉冲）。

### 四种 Motion Personality（每项目只选一型，全程一致）
| 型 | 气质 | 时长倾向 | 过冲 |
|---|---|---|---|
| Playful | 好玩、弹跳、可爱 | 短（150–300ms） | 10–20% |
| Premium | 优雅、克制、奢华 | 长（350–600ms） | 0% |
| Corporate | 干净、专业、仪表盘 | 中（200–400ms） | 0–3% |
| Energetic | 大胆、动感、兴奋 | 最短（100–250ms） | 15–30% |

品牌动效身份 = 三个常量定死：一条签名缓动曲线（占 80% 动效）、三个时长档（quick/standard/slow）、一种入场样式。
注：过冲（overshoot）只用于**非交互的展示/视频动效**；交互弹簧仍守 better-motion 的 bounce 恒 0。

### 迪士尼 12 原则（UI/视频适配，原文在原仓 director/disney-principles.md，已逐条核对完整）
1. Squash and Stretch 挤压拉伸（按钮按下约 [1.2,0.8] 量级示意，交互落地按 0.96 定版）
2. Anticipation 预备动作
3. Staging 舞台调度（同一时刻只让观众看一件事）
4. Straight Ahead vs Pose to Pose（视频逐帧 vs 关键帧规划，UI/代码动画用 Pose to Pose）
5. Follow Through and Overlapping Action 跟随与重叠
6. Slow In and Slow Out 缓入缓出
7. Arcs 弧线（空间移动走弧不走直）
8. Secondary Action 次级动作
9. Timing 时间掌控（节奏即性格）
10. Exaggeration 夸张（按性格定幅度，Corporate 忌夸张）
11. Solid Drawing 立体感/体积可信
12. Appeal 吸引力（杀手：抖动、时序不一致、戛然而止、全员同速）

组合速查（上游给的配方）：按钮 = 预备+挤压拉伸+跟随+次级+Timing；卡片入场 = 预备+弧线+缓入缓出+跟随+Staging；成功庆祝 = 夸张+次级+Timing+挤压拉伸+Appeal；错误抖动 = Timing+缓入缓出+Staging（**不加夸张**）；加载转圈 = Timing+缓入缓出+Appeal。

### 情绪 → 动效映射（本技能独有，做片定调时最有用）
| 情绪 | 路径 | 缓动倾向 | 时长倾向 |
|---|---|---|---|
| Joy | 上扬弧线 | ease-out-back | 200–400ms |
| Calm | 平缓曲线 | 正弦 ease-in-out | 500–1000ms |
| Urgency | 直线、锐利 | ease-out | 100–200ms |
| Sadness | 下垂曲线 | ease-in-out | 600–1200ms |
| Surprise | 放射向外 | ease-out-expo | 150–300ms |
| Elegance | 长弧线 | (0.4,0,0.2,1) | 400–700ms |
| Playfulness | 不规则弧线 | ease-out-back | 200–350ms |

路径即语言：折线=紧张、曲线=友好、螺旋=俏皮、斜线=有目的、垂直=成长/重量、水平=进展。

### 编排：1/3 法则 + stagger 预算
- **1/3 距离**：任何运动不得一口气走超过 1/3 屏而无关键帧变化。
- **1/3 元素**：3 个以上元素时，同一时刻处于主动运动的不超过 1/3。
- 编排三规：Hero 先行或最醒目；全员入场方向一致（空间一致性）；反向运动——主角向右，环境层以 20–30% 速度向左，造深度。
- stagger 总时长守 500ms 上限（档位细节查 better-motion / 原仓 choreography.md）。

### 材质缓动（上游独有小表，定幅度时参考）
刚性（金属/石）慢 1.2×、过冲 0%；弹性（橡胶）快 0.8×、过冲 15–25%；流体（水）慢 1.5×、过冲 5%；纸 1.0×、3–5%；气体（烟）慢 2.0×、0%；玻璃 0.9×、0%。

### 硬规矩（上游 CRITICAL，菲菲采纳）
1. 空间移动永不用 linear（linear 只给转圈/进度条）。
2. 重要状态变化永不只用 opacity，必须搭 position 或 scale。
3. 永不一口气运动超过 1/3 屏。
4. 每个动效都要有主/次/环境三层，缺层就是「廉价感」的头号来源。

### 故障速查
像机器人 → 缓动太直、没弧线；太慢 → 时长超标、改 ease-out；廉价扁平 → 缺次级+环境层；太吵 → 违反 1/3 元素法则、降幅度；没性格 → 全场一条通用缓动，套 Personality 原型统一。

## 实测（2026-11-27）
纯文本技能无可执行功能，实测 = 文件完整性核对：原仓共 21 个文件、技能正文 18 个 .md 合计 1,770 行（SKILL.md 332 行 + director 8 篇 + patterns 4 篇 + reference 5 篇）；迪士尼 12 原则逐条在 disney-principles.md 中齐全（1–12 编号连续、无缺条）；8 问清单、四性格表、情绪映射表、1/3 法则均与 SKILL.md 索引互相印证。核对通过。

## 使用规矩
- 只在定调阶段用它；落代码/落片时数值回到 better-motion 定版。
- 不连 Creator MCP，不跑任何上游安装命令（本来也没有）。
- 原仓全文在 ~/workspace/motion-design-lab/repo/skills/motion-design/，深挖某篇时直接读原文，菲菲版只做提炼与分工。
