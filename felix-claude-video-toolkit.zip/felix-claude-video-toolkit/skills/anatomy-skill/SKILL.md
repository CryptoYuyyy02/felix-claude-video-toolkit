---
name: anatomy-skill
description: Anatomy 等距图解菲菲版：把一个技术概念或真实物件画成精密等距机械图——多零件凸体、四调着色、画家顺序、可交互拆解页（anatomy 本体），以及把物件做成爆炸视图+产品揭晓短片（anatomy-reveal 支线，模板自带咖啡机 82 零件范例）。用于文档/文章/落地页的等距 explainer、产品结构讲解、拆解图与 reveal 视频；像素 3D 出图查 ink-studio，给 spec 出竖版动画查 claude-animation-skills。源 wheresryan22/anatomy + annnguyentt/anatomy-reveal-skill（均 MIT），菲菲手工重写。
---

# Anatomy 等距图解（菲菲适配，2026-11-27 装+实测）

来源：主人点选帖 @3three_AI 2125791906022175110（20 仓库清单第 5、6 件）。
上游两仓（同一 Anatomy kit 血统，菲菲合并为一个技能、两条支线，不拆两个技能避免重复）：
- **本体** github.com/wheresryan22/anatomy，MIT，29,406 星 / 2,497 fork（2026-11-27 GitHub API 实读；注：帖子里只写 3D 机械交互图，这个星数对技能仓异常高，按 API 实读记录、不作质量背书），原仓 ~/workspace/anatomy-lab/repo（tarball 落地 27 MB / 173 个文件）
- **Reveal 支线** github.com/annnguyentt/anatomy-reveal-skill，MIT，158 星 / 15 fork，原仓 ~/workspace/anatomy-lab/reveal/repo（3.0 MB / 40 个文件）

## 审计结论（2026-11-27）
**本体：**
- 纯 Node（≥20.10）+ 无头 Chrome 做校验/截图，无 npm 依赖清单要装的东西在示例构建路径上（示例 build.mjs 只用仓内 kit + Node 内置模块，本机实测零安装跑通）。
- 子进程只出现在校验脚本里：`scripts/turn-check.mjs` 等 spawn 本机 Chrome 无头打开本地页面、fetch 只打 `127.0.0.1` 的 DevTools 端口——本机自检用途，非外发。
- **唯一外发口子：`scripts/publish.mjs`**——把成品图推到 Anatomy 社区 gallery 的 GitHub 仓库（git fetch/push 到 github.com、需 gh CLI 登录）。**菲菲规矩：禁用 publish.mjs，不往社区画廊推任何东西**，除非主人单独点头。
- 其余 scripts 多为 *.test.mjs 几何审计测试（audit/capture/drive 等）。

**Reveal 支线：**
- 模板代码的子进程都是调本机工具：`template/motion/encode.mjs` spawn ffmpeg 与 ImageMagick `magick` 做编码/帧平均；`template/scripts/browser.mjs` 用 puppeteer-core 起本机 Chrome。
- **`scripts/new-project.mjs` 会自动 `npm install`（装 puppeteer-core）并连跑构建——按菲菲规矩不直接跑它**；要用时手动 cp template 到项目目录、再单独决定是否装 puppeteer-core。
- 无密钥、无遥测、无第三方上传。

## 两条支线怎么选
| 需求 | 支线 | 产物 |
|---|---|---|
| 把一个概念/系统/算法画成精密等距机械图，可交互、带读数 | 本体 anatomy | 单文件 HTML（SVG 图 + 标题卡 + 实时 readout），可出 A4 PDF |
| 把一个真实物件（产品/工具/家具…）做成可拖动拆解页 + 爆炸揭晓短片 | Reveal | figure.html 拆解页 + MP4（9:16/4:5/1:1/16:9，30fps，默认 10 秒） |

共同内核：物件不描图、不贴图、不套现成 3D 模型——全部由许多小凸体零件按真实尺寸逐件搭出来，四调着色（按朝光面），绘制顺序由分离面求解（画家顺序），所以能任意转角度、能拆开、数字读数与运动部件同源。

## 本体用法
- 9 个自带示例（examples/）：dial-indicator（最小，约 300 行）、desk-computer、arcade-cabinet、raptor-engine（火箭发动机，可拆 11 总成、自带几何审计）、ripple-tank、test-rig、spot-plate、push-button、turning-dial。**开工前先打开最接近的一个照着改，别从零写。**
- 构建：`node examples/<name>/build.mjs`（暗色）/ 加 `--light` 出浅色，产物是同目录独立 HTML。
- 几何审计：部分示例带 `node build.mjs --audit`，证明零件互不穿透、端点落在真实安装座上、重叠都按深度序绘制。做新图时这是验收标准，不是可选项。
- 环境：Node 20.10+；校验/截图脚本要 Chrome/Chromium，本机用 ~/.cache/ms-playwright 的 Chromium（1208/1248/1255 均在），必要时设 CHROME_PATH。
- 工时口径（上游自述）：一张 Hero 级图是认真活，别承诺随手几分钟出大图；先出 test page 再加深。

## Reveal 支线用法（要点，全文在原仓 SKILL.md + references/）
- 输入两路：①主人给照片——只当参考研究轮廓/比例/材质/控件，形状全部重建成几何，**禁止描图、嵌图、贴图**；②只给名字——先查真实尺寸（mm）、材质、控件、开启方式与内部结构（拆解资料最好），含糊型号选最常见款并声明假设。
- 动工前先交短 spec：尺寸、特征清单、按总成分组的零件清单、片中会动的 1–2 个特征。
- 模板范例：双锅炉咖啡机整机 82 个零件（template/object/geometry.mjs），kit 在 template/kit/（比本体多了 glass/pcb/porcelain/coffee 等材质）。
- 流程：手动复制 template → 改 object/geometry.mjs 搭物件 → `node object/build.mjs` 出拆解页 → `node motion/build.mjs --duration <3–60秒> --ratio <…>` 编排 → `node motion/render.mjs` 渲染（上游称约 2 分钟/秒，先估时）→ `node motion/encode.mjs` 出 MP4 → 抽帧亲查。
- 规矩：凸体零件、纸面look（暖白纸底+墨线+四调填充）默认不改、商标logo默认中性化（主人要求忠实复刻才画）、成片无声。

## 实测（2026-11-27）
- **本体跑通**：`node examples/dial-indicator/build.mjs` 与 `--light` 均 exit 0，各生成 dial-indicator.html / dial-indicator-light.html（各 134 KB，内含 6 个 `<svg` 块），产物在 ~/workspace/anatomy-lab/repo/examples/dial-indicator/。零安装、零联网。
- **Reveal 未在本机跑通构建，如实记**：其脚手架脚本会 npm install puppeteer-core，按规矩没跑；只验了随仓 demo 成片真实存在且参数对版：demo/espresso-machine.mp4 = h264、720×1280（9:16）、10.00 秒、1,813,290 字节。正式用 Reveal 前需主人点头装 puppeteer-core 这一个依赖，再按手动流程首跑。

## 分工
| 需求 | 查谁 |
|---|---|
| 等距精密机械图解 / 产品拆解页 / 爆炸揭晓片 | **本技能** |
| 像素风 3D 场景出图（SDF→Gaussian Splats，游戏封面/概念图） | `ink-studio`（像素画风、静态出图为主，无真实尺寸零件体系） |
| 给 JSON spec 快速出竖版动画（折线图/路线图/爆炸拆解简版等 8 类） | `claude-animation-skills`（它的 breakdown 是快速简版拆解；要精密零件级、真实尺寸、可交互拆解才升级到本技能） |
| 线稿等距小人/线条动画（原帖第 4 件 hairline） | 未装，备查；与 claude-animation-skills 极简线条重叠 |

## 使用规矩
- 禁用本体 publish.mjs（社区画廊外发），除非主人单独点头。
- 不跑 Reveal 的 new-project.mjs 一键脚本；手动复制模板、依赖单独报批。
- 数字与尺寸必须真实或声明假设，不许编零件数/尺寸充门面（上游纪律，菲菲沿用）。
